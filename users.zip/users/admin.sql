CREATE TABLE admin (
id int(40),
user_name varchar(120),
user_pass varchar(50),
); 
INSERT INTO admin (id, user_name, user_pass)
VALUES ('1', 'alberto280', 'BZ424869');