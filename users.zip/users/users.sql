CREATE TABLE users (
id int(11),
username varchar(120),
user_pass varchar(50),
email varchar(100) UNIQUE,
); 